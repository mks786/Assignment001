interface Vehicle {
    getVehicleType() : string;
}
export default Vehicle;
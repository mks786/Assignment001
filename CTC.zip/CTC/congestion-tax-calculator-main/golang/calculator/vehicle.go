package calculator

type Vehicle interface {
	getVehicleType() string
}

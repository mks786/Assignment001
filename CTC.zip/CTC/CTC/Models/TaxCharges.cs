﻿using congestion.calculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CTC.Models
{
    public class TaxCharges
    {
        public int WithSingleChargeRule { get; set; }
        public int WithOldSolution { get; set; }
    }
}

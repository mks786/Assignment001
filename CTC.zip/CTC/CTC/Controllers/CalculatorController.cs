﻿using congestion.calculator;
using CTC.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CTC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalculatorController : ControllerBase
    { 
        // POST api/<CalculatorController>
        [HttpPost]
        public TaxCharges Post([FromBody] VehicleData vehicleData)
        {
            CongestionTaxCalculator _congestionTaxCalculator = new CongestionTaxCalculator();
            TaxCharges taxCharges= new TaxCharges();
            Array.Sort(vehicleData.dates);
            Vehicle vehicle = new Car();
            switch (vehicleData.vehicleType) {

                case "Car":
                case "car":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Car(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Car(), vehicleData.dates);
                    break;
                case "Bus":
                case "bus":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Bus(), vehicleData.dates);
                        taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Bus(), vehicleData.dates);
                    break;
                case "Emergency":
                case "emergency":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Emergency(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Emergency(), vehicleData.dates);
                    break;

                case "Diplomat":
                case "diplomat":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Diplomat(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Diplomat(), vehicleData.dates);
                    break;

                case "Motorcycle":
                case "motorcycle":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Motorbike(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Motorbike(), vehicleData.dates);
                    break;

                case "Military":
                case "military":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Military(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Military(), vehicleData.dates);
                    break;

                case "Tractor":
                case "tractor":
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Tractor(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Tractor(), vehicleData.dates);
                    break;
                case "Foreign":
                case "foreign":
                        taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Foreign(), vehicleData.dates);
                        taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Foreign(), vehicleData.dates);
                    break;
                default:
                    taxCharges.WithOldSolution = _congestionTaxCalculator.GetTax(new Car(), vehicleData.dates);
                    taxCharges.WithSingleChargeRule = _congestionTaxCalculator.GetTaxWithSingleChargeRule(new Car(), vehicleData.dates);
                    break;
            }

            return taxCharges;
        }

    }
}
